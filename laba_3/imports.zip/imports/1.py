from math import ceil, floor
from math import fabs, isfinite
from math import trunc, pow, sqrt, cos, pi

print(ceil(5.1)) # Округление вверх
num = -8.2
low_num = floor(num) # Округление вниз
print(low_num)
print(fabs(low_num)) # Модуль числа
print(isfinite(5.5)) # Является ли числом
print(trunc(num)) # Целая часть
print(pow(num, 0)) # Возведение в степень
print(sqrt(fabs(low_num))) # Корень из числа
print(cos(pi)) # Тригонометрические функции